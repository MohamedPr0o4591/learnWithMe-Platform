# Analog and Digital Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/orkhan-abbasli/pen/QyXxqv](https://codepen.io/orkhan-abbasli/pen/QyXxqv).

Analog and Digital Clock